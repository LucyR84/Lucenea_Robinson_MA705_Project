# -*- coding: utf-8 -*-
"""
Created on Sun Dec  4 02:42:27 2022

@author: Lucy
"""


import json
import pandas as pd
import glob

# Get all the game data json files
file_paths = glob.glob('C:/Users/Lucy/Spyder/MA705/Individual Project/RAWG */*.json')


# Create blank dataframe to hold the game data
game_data_columns = ['Release Date', 'Intial Release', 'Game Name', 'Rating', 
                     'Ratings Result','Ratings Percent', 'Ratings Count', 
                     'Metacritic Rating', 'Score', 'ESRB Rating', 'Avg Playtime',
                     'Platforms', 'Stores', 'Genres', 'Tags', 'RAWG Game Page']
rawg_games_data = pd.DataFrame(columns=game_data_columns)

# Create sets to hold unique names of platforms, stores, tags, and genres
platforms_set = set()
stores_set = set()
genres_set = set()
tags_set = set()


# Get the file paths for RAWG data

for path in file_paths:
    print(path)
    f = open(path)
    data = json.load(f)
    
    for result in data['results']:
        print(result['name'])
    
        platforms_list = []
        stores_list = []
        tags_list = []
        genres_list = []
        
        released = result['released'] 
        tba = result['tba'] # if true released dated is for initial release
        name = result['name']
        metacritic = result['metacritic']
        score = result['score']
        
        
        playtime = result['playtime'] #average playtime
        link = 'https://rawg.io/games/' + result['slug']
        
        # Get esrb rating
        if result['esrb_rating'] != None:
            esrb_rating = result['esrb_rating']['name']
        else:
            esrb_rating = None
        
        # Getting ratings info
        rating = result['rating']
        rating_top = result['rating_top']
        
        ratings_count = 0
        ratings_result = None
        ratings_percent = None
        
        if result['ratings'] != []:
            for rating_dict in result['ratings']:
                ratings_count += rating_dict['count']
                
                if rating_dict['id'] == rating_top:
                    ratings_result = rating_dict['title']
                    ratings_percent = rating_dict['percent']
    
        
        # Get platforms
        if result['platforms'] != None:
            for platform_dict in result['platforms']:
                platforms_list.append(platform_dict['platform']['name'])
                platforms_set.add(platform_dict['platform']['name'])
        
        # Get stores and update master stores set
        if result['stores'] != None:
            for store_dict in result['stores']:
                stores_list.append(store_dict ['store']['name'])
                stores_set.add(store_dict ['store']['name'])
            
        # Get Genres
        if result['genres'] != None:
            for genre_dict in result['genres']:
                genres_list.append(genre_dict['name'])
                genres_set.add(genre_dict['name'])
            
        # Get tags, if any
        if result['tags'] != None:
            for tag_dict in result['tags']:
                if tag_dict['language'] == 'eng':
                    tags_list.append(tag_dict['name'])
                    tags_set.add(tag_dict['name'])
                else:
                    pass
 
        
        new_row = {'Release Date':released, 'Intial Release':tba, 'Game Name':name, 
                   'Rating':rating, 'Ratings Result':ratings_result,
                   'Ratings Percent':ratings_percent, 'Ratings Count':ratings_count, 
                   'Metacritic Rating':metacritic, 'Score':score, 'ESRB Rating':esrb_rating, 
                   'Avg Playtime':playtime,'Platforms':','.join(platforms_list), 
                   'Stores':','.join(stores_list), 'Genres':','.join(genres_list), 
                   'Tags':','.join(tags_list), 'RAWG Game Page':link}
        
        add_row = pd.DataFrame(new_row, index=[0])
        rawg_games_data = pd.concat([rawg_games_data, add_row], ignore_index=True)

# Convert sets to dataframe
platforms_df = pd.DataFrame(list(platforms_set), columns = ['Platforms'])
stores_df = pd.DataFrame(list(stores_set), columns = ['Stores'])
genres_df = pd.DataFrame(list(genres_set), columns = ['Genres'])
tags_df = pd.DataFrame(list(tags_set), columns = ['Tags'])

# Save data to CSVs
rawg_games_data.to_csv('/Users/Lucy/Spyder/MA705/Individual Project/rawg_games_data.csv', 
                       index = False)
platforms_df.to_csv('/Users/Lucy/Spyder/MA705/Individual Project/game_platforms.csv', 
                       index = False)
stores_df.to_csv('/Users/Lucy/Spyder/MA705/Individual Project/game_stores.csv', 
                       index = False)
genres_df.to_csv('/Users/Lucy/Spyder/MA705/Individual Project/game_genres.csv', 
                       index = False)
tags_df.to_csv('/Users/Lucy/Spyder/MA705/Individual Project/game_tags.csv', 
                       index = False)