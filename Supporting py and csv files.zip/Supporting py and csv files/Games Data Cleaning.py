# -*- coding: utf-8 -*-
"""
Created on Sun Dec 11 10:32:37 2022

@author: Lucy
"""

import pandas as pd
import numpy as np

rawg_games = pd.read_csv("C:/Users/Lucy/Spyder/MA705/Individual Project/rawg_games_data.csv")

rawg_games_ordered = rawg_games.sort_values(by=['Release Date'])


"""
Score (0) column dropped due to because all values are null
Metacritic column dropped due to low non-null values (3,003 out of 752002)
Ratings Results column dropped due to low non-null values (8,137 out of 752002)
Ratings Percent column dropped due to low non-null values (8,137 out of 752002)
"""
rawg_games_ordered = rawg_games_ordered.drop(labels = ['Ratings Result', 
                                                       'Ratings Percent',
                                                       'Metacritic Rating', 
                                                       'Score'], axis = 1)

# Removed duplicates based on RAWG web page because each webpage is unique
rawg_games_Full = rawg_games_ordered.drop_duplicates(['RAWG Game Page'])
rawg_games_Full.reset_index(inplace = True, drop = True)


"""
'Rating' kept to indicate ratings though most is zero. Ratings count kept to show
how many people rated the game. Low rating count give a 0 rating score. Also, despite
ESRB rating having low non-null values, as it it pertinent summary info for games
it was deemed necessary to keep. null ESRB ratings were changed to 'Not Rated'
"""

rawg_games_Full["ESRB Rating"].replace([np.nan], [None])
rawg_games_Full["ESRB Rating"].fillna("Not Rated", inplace=True)

"""for x in range(len(rawg_games_Full)):
    if str(rawg_games_Full.iloc[x,5]) == 'nan':
        rawg_games_Full.iloc[x,5] = "Not Rated"
        """


# Find the rows/indices game name is null,
game_name_null_indices = rawg_games_Full['Game Name'].isnull()[rawg_games_Full['Game Name'].isnull() == True].index

"""
indices 54796 and 125615 had NaNs for Game name but as they had info for Genre I looked
at RAWG Website and they are actual games so added the actual string names
"""
rawg_games_Full.loc[[54796, 125615],'Game Name'] = ['NaN', 'NULL']
#print(rawg_games_Full['Game Name'].iloc[[54796, 125615]] )


# Check whether for rows where the variables of interest are all Null
platform_null_index = set(rawg_games_Full[rawg_games_Full['Platforms'].isnull() == True].index)
stores_null_index = set(rawg_games_Full[rawg_games_Full['Stores'].isnull() == True].index)
genres_null_index = set(rawg_games_Full[rawg_games_Full['Genres'].isnull() == True].index)
tags_null_index = set(rawg_games_Full[rawg_games_Full['Tags'].isnull() == True].index)

not_games_indices = set.intersection(platform_null_index, stores_null_index,
                             genres_null_index, tags_null_index)

#print(not_games_indices)
"""
There was only one index [27313] in which there are no values for all 4 variables (platforms, 
Stores, Genres and Tags). 
"""
rawg_games_Full = rawg_games_Full.drop(index = 27313)


"""
For all the other Nulls in the 4 variables, the "Other" assigned to it a it makes sense they
are available by other means. For example some tags include "freeware" for some games that
did not have a value for "Stores" which can be downloaded straight from the web. Same idea
for platforms, as there may be other gaming mediums not listed in the RAWG database.
A few example revealed to be VR consoles.

Similarly,the 'Genres' variable only had 20 values and so RAWG Database may not have a 
category to put some games in, so "Other" was deemed acceptible to categorize them.

For tags, "Other" was deemed an appropriate tag to account for those games with no tags since
some games already had other in them. 
"""

# only the 4 variables had null values so filled all values at once
rawg_games_Final = rawg_games_Full.fillna('Other')


"""
The game_stores and game_genres CSVs with the list of stores and genres repectively were 
manually updated to include "Other". (Tags already included "Other")

A Copy of the platforms csv was updated manually (named game_platforms_updated to
include other and also summarize them into the following types of platforms: Hand-held 
Consoles,Consoles, Mobile, Computer, Web, and Other (just for those labeled "Other").
"""

# Add in column for "Platform types

game_platforms = pd.read_csv("C:/Users/Lucy/Spyder/MA705/Individual Project/game_platforms_updated.csv")

rawg_games_Final['Platform Types'] = ""

for x in range(len(rawg_games_Final)):
    type_list = []
    for p, ptype in zip(game_platforms['Platforms'],game_platforms['Type']):
        if ptype in type_list:
            pass
        elif p in rawg_games_Final.iloc[x,7]: 
            type_list.append(ptype)
        else:
            pass
    
    rawg_games_Final.iloc[x,12] = ','.join(type_list)


rawg_games_Final['Release Date']= pd.to_datetime(rawg_games_Final['Release Date'])
rawg_games_Final['Year'] = rawg_games_Final['Release Date'].dt.strftime('%Y')

year_summary = rawg_games_Final.groupby(rawg_games_Final['Year'])['Release Date','Game Name'].count()
year_summary.reset_index(inplace = True)
years_summary = year_summary[['Year','Release Date']].rename(columns={'Release Date': 'Number of Games Released'})



#Get link column to markdown format
rawg_games_Final['Link'] = ['['+ x +']' + '(' + x + ')' for x in rawg_games_Final['RAWG Game Page']]
        

#save final dataframes to csv
rawg_games_Final.to_csv('/Users/Lucy/Spyder/MA705/Individual Project/rawg_games_Final.csv', 
                      index = False)

years_summary.to_csv('/Users/Lucy/Spyder/MA705/Individual Project/year_summary.csv', 
                       index = False)
