# -*- coding: utf-8 -*-
"""
Created on Thu Dec  1 17:08:37 2022

@author: Lucy
"""

import requests
import json
import pandas as pd

# RAWG API URL with call parameter and API Key
url = "https://api.rawg.io/api/games?key=56cb32c09f2541aab19f35ecb37b149e"

"""

Save as many pages of games starting with 2022
Try to get at lease 3 years
there is 250 page limit with up to 40 results per page
"""

year = '2015' # Year for data being called

"""
Counter used to assign a number each api call for that year. 
***WHEN THERE IS A BAD RESPONSE REMEMBER TO CHANGE THE COUNT TO 
THE NUMBER PRINTED IN THE CONSOLE BEFORE USING the "BAD RESPONSE 
FOR LOOP" TO PICK UP WHERE LEFT OFF****
""" 
count = 1 


# Create a list of strings of dates of 10 day intervals for api parameter
dates = pd.date_range(start = "2015-01-01", end="2015-12-31")
date_str = [x.strftime("%Y-%m-%d") for x in dates]
date_pairs = []

for x in range(0,len(date_str), 10):
    if x > (len(date_str) - 10):
        date_pairs.append(date_str[x]+','+ date_str[-1])
    else:
        date_pairs.append(date_str[x]+','+date_str[x + 9])
        

"""
For loop to capture game data for each year per the 10 day intervals.
If there was a bad response, COMMENT THIS OUT and UNCOMMENT BAD RESPONSE FOR LOOP.
After using the BAD RESPONSE FOR LOOP start at the date interval following the
one that had the bad response.
"""
for period in date_pairs: 
    for pg_num in range(1,251):
        print("pg", pg_num) #keep track of page number for the 10 day period being looped
            
        params = {"page_size":40,"page":pg_num, "ordering":"released",
                  "dates":period}
        
        # make api call
        games_request = requests.request("GET", url,params=params)
        games_request.raise_for_status()
        
        # Save API Call to folder
        with open('RAWG_Games_'+ year + "_" + str(count) +'.json', 'w') as f:
            json.dump(games_request.json(), f)
            
        count += 1 # increase api call number
        print(count) # keep track of the api call number for the year
        
        # assign the api call to data and check if it is the last page for the period
        data = games_request.json() 
        
        if (data['next'] == None):
            break # break loop if last page


#### BAD RESPONSE FOR LOOP###     
        
"""
For loop to pick continue the api call for period when there is a bad response.
Take the page number and the count number printed in the console, and the date 
period shown in the error message to pick up the NEXT AND REMAINING pages of the
period.
******REMEMBER TO CHNAGE "COUNT" ABOVE BEFORE STARTING THE LOOP******
"""

"""for pg_num in range(1,251): # change range starting number to pg_num in the console
    print("pg", pg_num)
        
    params = {"page_size":40,"page":pg_num, "ordering":"released",
              "dates":"2022-02-11,2022-02-11"} # Change date here 
    
    games_request = requests.request("GET", url,params=params)
    games_request.raise_for_status()
    
    with open('RAWG_Games_'+ year + "_" + str(count) +'.json', 'w') as f:
        json.dump(games_request.json(), f)
        
    count += 1
    print(count)

    data = games_request.json()
    
    if (data['next'] == None):
        break"""

